<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>this is my example, i will learning everyday</title>
</head>

<body>
    <?php
    $connect = mysqli_connect('localhost', 'popo', 'password', 'belajar');
    $query = mysqli_query($connect, "SELECT nama, umur, gambar FROM customer ORDER BY id");
    while ($printed = mysqli_fetch_assoc($query)):
    ?>
    <div class="container">
        <div class="avatar">
            <img src="<?php echo $printed['gambar']; ?>" alt="nophoto.jpg" style="width: 150px;">
        </div>
        <div class="data">
            <h4><code><?php echo $printed['nama']; ?></code></h4>
            <span><code><?php echo $printed['umur']; ?></code></span>
        </div>
    </div>
    <?php endwhile; ?>
</body>
<style type="text/css">
html,
body {
    padding: 0;
    margin: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: sans-serif;
}

.container {
    width: 200px;
    height: 230px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding-block: 2rem;
    padding-inline: 1rem;
    text-align: center;
    border: 1px solid black;
}

.container .avatar {
    padding: 10px;
    border: 1px solid black;
    width: 160px;
}
</style>

</html>