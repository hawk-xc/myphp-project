<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>this is my example, i will learning everyday</title>
</head>

<body>
    <?php
    $connect = mysqli_connect('localhost', 'popo', 'password', 'belajar');
    $query = mysqli_query($connect, "SELECT nama, umur, gambar FROM customer ORDER BY id");
    while ($printed = mysqli_fetch_assoc($query)):
        ?>
    <div class="container">
        <div class="avatar">
            <img src="<?php echo $printed['gambar']; ?>" alt="gambar saat ini" style="width: 50px;">
        </div>
        <?php endwhile; ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <input type="text" name="nama" value="<?php echo $printed['nama']; ?>" id="nama" placeholder="nama">
            <input type="file" name="gambar" id="gambar">
            <input type="submit" name="submit" value="kirim query">
        </form>
        <?php
        if (isset($_POST['submit']) > 0):
            // avatar dir
            $dir = 'upload/';

            $namaFile = $_FILES['gambar']['name'];  
            $extFile = $namaFile;
            $tmpName = $_FILES['gambar']['tmp_name'];
            $errorCode = $_FILES['gambar']['error'];
            $sizeFile = $_FILES['gambar']['size'];

            $EXT = ['jpg', 'png', 'jpeg'];
            $extFile = explode(".", $namaFile);
            $extFile = end($extFile);

            $namaFile = "upload/" . uniqid() . "." . $extFile;
            
            $status = True;

            if (!in_array($extFile, $EXT)):
                echo "<code>error : extensions must [png, jpg, jpeg]</code>";
                $status = False;
            endif;

            if ($sizeFile > 1500000):
                echo "<code>error : size to big!!!</code>";
                $status = False;
            endif;

            if ($status):
                move_uploaded_file($tmpName, $namaFile);
                mysqli_query($connect, "UPDATE customer SET gambar = '$namaFile' WHERE id=1");
                echo "<code>success: avatar successful upload and change!!";
            endif;
        endif;
        ?>
    </div>
</body>
<style type="text/css">
html,
body {
    padding: 0;
    margin: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: sans-serif;
}

.container {
    width: 200px;
    height: 230px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding-block: 2rem;
    padding-inline: 1rem;
    border: 1px solid black;
    gap: 1rem;
}

.container .avatar {
    padding: 10px;
    border: 1px solid black;
    width: 160px;
}
</style>

</html>