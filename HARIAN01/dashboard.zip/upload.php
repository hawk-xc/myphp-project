<?php
$data_str = $_POST;

function uploadfiles($data_files) {
    $target_dir = 'upload/';
    $target_image = $target_dir . basename($data_files['gambar']['name']);
    $isUpload = True;

    // check the extension is image or other
    $exten = strtolower(pathinfo($target_image,PATHINFO_EXTENSION));
    if ($exten != 'png' && $exten != 'jpg'):
        $isUpload = False;
        return "file extension is not accepted";
    endif;

    if (file_exists($target_image)):
        return "upload failed! <code>File Already Exist!!!</code>";
        $isUpload = False;
    endif;
    
    if (!$isUpload) {
        return "upload failure with no one know";
    }
    else {
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_image)) {
            return "image <code>" . htmlspecialchars(basename($_FILES['gambar']['name'])) . "</code> successful uploaded!!!";
        } 
        else {
            return "something error occured";
        }
    }
}
?>